import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as PageHero } from "./page-hero-Cka1p3b-.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as cn, c as serviceOptions, n as SiteShell, t as Button } from "./site-shell-DrBtHalz.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-DB74cFqp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-border bg-card px-3 text-sm text-foreground shadow-border transition-[border-color,box-shadow] duration-150", "placeholder:text-muted-foreground", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
		className: cn("text-sm font-medium text-foreground", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-32 w-full rounded-lg border border-border bg-card px-3 py-3 text-sm text-foreground shadow-border transition-[border-color,box-shadow] duration-150", "placeholder:text-muted-foreground", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
var schema = object({
	name: string().trim().min(2, "اكتب الاسم كاملاً"),
	email: string().trim().email("البريد غير صحيح"),
	company: string().trim(),
	service: string().min(1, "اختر موضوع الاستشارة"),
	message: string().trim().min(12, "أضف سطراً يوضح احتياجك")
});
var STORAGE_KEY = "manara-inquiries";
function ContactForm() {
	const [errors, setErrors] = (0, import_react.useState)({});
	const [sent, setSent] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)(false);
	function onSubmit(event) {
		event.preventDefault();
		const form = event.currentTarget;
		const data = {
			name: String(new FormData(form).get("name") ?? ""),
			email: String(new FormData(form).get("email") ?? ""),
			company: String(new FormData(form).get("company") ?? ""),
			service: String(new FormData(form).get("service") ?? ""),
			message: String(new FormData(form).get("message") ?? "")
		};
		const parsed = schema.safeParse(data);
		if (!parsed.success) {
			const next = {};
			for (const issue of parsed.error.issues) {
				const key = issue.path[0];
				if (typeof key === "string" && !next[key]) next[key] = issue.message;
			}
			setErrors(next);
			return;
		}
		setErrors({});
		setPending(true);
		try {
			const existing = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
			localStorage.setItem(STORAGE_KEY, JSON.stringify([{
				...parsed.data,
				at: (/* @__PURE__ */ new Date()).toISOString()
			}, ...existing]));
		} catch {}
		window.setTimeout(() => {
			setPending(false);
			setSent(true);
			toast.success("وصل طلبك. نعود إليك خلال يوم عمل.");
		}, 400);
	}
	if (sent) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-8 shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl text-foreground",
				children: "شكراً لثقتك."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-sm leading-relaxed text-muted-foreground",
				children: "وصل طلب الاستشارة. يراجع أحد الشركاء الرسالة ويعود إليك خلال يوم عمل واحد على البريد الذي أرسلته."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				className: "mt-6",
				onClick: () => setSent(false),
				children: "إرسال رسالة أخرى"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "space-y-5",
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الاسم",
				htmlFor: "name",
				error: errors.name,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "name",
					name: "name",
					autoComplete: "name",
					placeholder: "الاسم الكامل"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "البريد",
				htmlFor: "email",
				error: errors.email,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "email",
					name: "email",
					type: "email",
					autoComplete: "email",
					placeholder: "you@company.com",
					dir: "ltr",
					className: "text-start"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الشركة",
				htmlFor: "company",
				error: errors.company,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "company",
					name: "company",
					autoComplete: "organization",
					placeholder: "اختياري"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "موضوع الاستشارة",
				htmlFor: "service",
				error: errors.service,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					id: "service",
					name: "service",
					defaultValue: "",
					className: cn("flex h-11 w-full rounded-md border border-border bg-card px-3 text-sm text-foreground shadow-border", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						disabled: true,
						children: "اختر الخدمة"
					}), serviceOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: option,
						children: option
					}, option))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الرسالة",
				htmlFor: "message",
				error: errors.message,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "message",
					name: "message",
					placeholder: "صف القرار أو التحدي الذي تعملون عليه."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "w-full sm:w-auto",
				disabled: pending,
				children: pending ? "جارٍ الإرسال…" : "إرسال الطلب"
			})
		]
	});
}
function Field({ label, htmlFor, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor,
				children: label
			}),
			children,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-danger",
				children: error
			}) : null
		]
	});
}
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		eyebrow: "تواصل · ٠٥",
		title: "اكتب القرار المعلّق. نعود خلال يوم عمل.",
		lead: "الشركة، والموضوع، والوقت المتاح. نرد إن كان الطلب ضمن أبوابنا الستة."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 lg:grid-cols-2 lg:gap-20 lg:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-lg bg-card p-6 shadow-border sm:p-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "space-y-8 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs font-medium tracking-mark text-muted-foreground",
					children: "المكتب"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
					className: "mt-2 text-base text-foreground",
					children: [
						"مركز الملك عبدالله المالي",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"البرج ٣، الطابق ٢٧ — الرياض"
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs font-medium tracking-mark text-muted-foreground",
					children: "البريد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-base",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "mailto:hello@manara.sa",
						className: "text-foreground hover:opacity-70",
						children: "hello@manara.sa"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs font-medium tracking-mark text-muted-foreground",
					children: "الهاتف"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-base text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						dir: "ltr",
						className: "inline-block",
						children: "+966 11 414 0080"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs font-medium tracking-mark text-muted-foreground",
					children: "المكاتب"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-base text-foreground",
					children: "الرياض · دبي · القاهرة"
				})] })
			]
		})]
	}) })] });
}
//#endregion
export { ContactPage as component };
