import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as SiteShell, o as folders, t as Button } from "./site-shell-DrBtHalz.mjs";
import { o as Stats, r as ContactBand } from "./sections-B_ZJtSam.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BXyzUshk.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-center gap-10 px-5 py-14 sm:px-8 lg:grid-cols-2 lg:gap-16 lg:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hero-in text-xs font-medium tracking-mark text-muted-foreground",
						children: "منارة · الرياض منذ ٢٠٠٨"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "hero-in mt-4 text-display tracking-tight text-foreground",
						style: { animationDelay: "80ms" },
						children: [
							"وضوح للقرار.",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"مسافة للنمو."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hero-in mt-5 max-w-md text-base leading-relaxed text-muted-foreground sm:text-lg",
						style: { animationDelay: "160ms" },
						children: "نرافق مجالس الإدارة في الاستراتيجية والتحول والتوسع — حين يكبر الطموح أسرع من النظام."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-in mt-8 flex flex-col gap-3 sm:flex-row sm:items-center",
						style: { animationDelay: "240ms" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/contact",
								children: ["اطلب استشارة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/about",
								children: "من نحن"
							})
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hero-in overflow-hidden rounded-lg",
					style: { animationDelay: "160ms" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/hero.jpg",
						alt: "أبراج مالية معاصرة عند الغسق في الرياض",
						className: "aspect-photo w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10 lg:aspect-square"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-mark text-muted-foreground",
						children: "خريطة الموقع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 text-title tracking-tight text-foreground",
						children: "خمسة أقسام. مسار واحد."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm text-muted-foreground",
						children: "الرئيسية، من نحن، الخدمات، أعمالنا، وتواصل — بهوية عصرية واحدة."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-10 grid gap-4 sm:grid-cols-2",
					children: folders.map((folder) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: folder.to,
						className: "group flex h-full flex-col overflow-hidden rounded-lg bg-card shadow-border transition-transform duration-200 hover:-translate-y-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: folder.image,
							alt: folder.imageAlt,
							className: "aspect-video w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-1 flex-col p-5 sm:p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-medium text-muted-foreground",
									children: [
										folder.num,
										" · ",
										folder.label
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 text-lg font-medium text-foreground",
									children: folder.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 flex-1 text-sm leading-relaxed text-muted-foreground",
									children: folder.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-4 inline-flex items-center gap-2 text-sm font-medium text-foreground",
									children: ["ادخل القسم", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4 transition-transform duration-150 group-hover:-translate-x-0.5" })]
								})
							]
						})]
					}) }, folder.to))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactBand, {})
	] });
}
//#endregion
export { Home as component };
