import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as PageHero } from "./page-hero-Cka1p3b-.mjs";
import { n as SiteShell } from "./site-shell-DrBtHalz.mjs";
import { c as WorkShowcase, i as InsightsList, n as ClientRow, r as ContactBand } from "./sections-B_ZJtSam.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/work-DtVHvZvt.js
var import_jsx_runtime = require_jsx_runtime();
function WorkPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "أعمالنا · ٠٤",
			title: "أثر يُقاس، لا عرض يُروى.",
			lead: "ثلاث حالات من التجزئة والطاقة والخدمات المالية. المنهج واحد: رهان واضح، وإيقاع يُراجع."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkShowcase, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientRow, {})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-mark text-muted-foreground",
						children: "رؤى"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 text-title tracking-tight text-foreground",
						children: "ملاحظات من غرف القرار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsList, {})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactBand, {})
	] });
}
//#endregion
export { WorkPage as component };
