import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as cn, d as steps, f as team, i as clients, l as services, r as cases, s as insights, t as Button, u as stats } from "./site-shell-DrBtHalz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sections-B_ZJtSam.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Stats() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl grid-cols-2 gap-px bg-border sm:grid-cols-4",
			children: stats.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-background px-5 py-8 sm:px-8 sm:py-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-3xl font-medium tracking-tight text-foreground sm:text-4xl",
					children: item.value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: item.label
				})]
			}, item.label))
		})
	});
}
function Approach() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 lg:grid-cols-2 lg:gap-16 lg:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-mark text-muted-foreground",
					children: "المنهجية"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-3 text-title tracking-tight text-foreground",
					children: [
						"ثلاثة مواقف.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"بلا ضجيج استشاري."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-md text-sm leading-relaxed text-muted-foreground sm:text-base",
					children: "لا نبيع إطاراً جاهزاً. ندخل غرفة القرار، نرتب ما يستحق الانتباه، ونترك إيقاعاً تستطيع الشركة إدارته بعد أن نغادر."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 overflow-hidden rounded-lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/about.jpg",
						alt: "قاعة اجتماعات هادئة تطل على المدينة",
						className: "aspect-photo w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10"
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col divide-y divide-border border-t border-border",
				children: steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[auto_1fr] gap-4 py-8 sm:gap-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-2xl font-medium text-muted-foreground",
						children: step.num
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-medium text-foreground",
						children: step.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted-foreground sm:text-base",
						children: step.body
					})] })]
				}, step.num))
			})]
		})
	});
}
function ServicesGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-px bg-border sm:grid-cols-2",
		children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "bg-card p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted-foreground",
					children: service.num
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-4 text-lg font-medium text-foreground",
					children: service.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: service.body
				})
			]
		}, service.num))
	});
}
function WorkShowcase() {
	const [active, setActive] = (0, import_react.useState)(cases[0].id);
	const current = cases.find((item) => item.id === active) ?? cases[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:gap-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col",
			children: [cases.map((item) => {
				const selected = item.id === current.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setActive(item.id),
					className: cn("border-t border-border py-5 text-start transition-opacity duration-200", selected ? "opacity-100" : "opacity-45 hover:opacity-100"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							item.client,
							" · ",
							item.sector
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-base font-medium text-foreground sm:text-lg",
						children: item.title
					})]
				}, item.id);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-t border-border" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "overflow-hidden rounded-lg bg-card shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: current.image,
				alt: current.imageAlt,
				className: "aspect-video w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 p-6 sm:p-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-foreground",
					children: current.result
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted-foreground sm:text-base",
					children: current.body
				})]
			})]
		})]
	});
}
function ClientRow() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-border pt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-mark text-muted-foreground",
			children: "عملنا مع"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 flex flex-wrap gap-x-8 gap-y-3",
			children: clients.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-sm text-foreground",
				children: name
			}, name))
		})]
	});
}
function TeamGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-4",
		children: team.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: person.image,
					alt: person.name,
					className: "aspect-portrait w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-base font-medium text-foreground",
					children: person.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: person.role
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted-foreground",
					children: person.bio
				})
			] })]
		}, person.name))
	});
}
function InsightsList() {
	const [open, setOpen] = (0, import_react.useState)(insights[0].title);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "divide-y divide-border border-y border-border",
		children: insights.map((item) => {
			const isOpen = open === item.title;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-expanded": isOpen,
				onClick: () => setOpen(isOpen ? null : item.title),
				className: "flex w-full items-start justify-between gap-6 py-6 text-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted-foreground",
					children: item.date
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-lg font-medium text-foreground sm:text-xl",
					children: item.title
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("mt-1 text-xl leading-none text-muted-foreground transition-transform duration-200", isOpen && "rotate-45"),
					"aria-hidden": "true",
					children: "+"
				})]
			}), isOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pb-6 text-sm leading-relaxed text-muted-foreground sm:max-w-2xl sm:text-base",
				children: item.body
			}) : null] }, item.title);
		})
	});
}
function ContactBand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-inverse text-inverse-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-6 px-5 py-16 sm:flex-row sm:items-center sm:justify-between sm:px-8 sm:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-mark text-inverse-foreground/55",
				children: "الخطوة التالية"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 max-w-lg text-title tracking-tight text-inverse-foreground",
				children: "إن كان القرار ثقيلاً، نبدأ من هنا."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "inverse",
				size: "lg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/contact",
					children: ["اطلب استشارة", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })]
				})
			})]
		})
	});
}
//#endregion
export { ServicesGrid as a, WorkShowcase as c, InsightsList as i, ClientRow as n, Stats as o, ContactBand as r, TeamGrid as s, Approach as t };
