import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as PageHero } from "./page-hero-Cka1p3b-.mjs";
import { n as SiteShell } from "./site-shell-DrBtHalz.mjs";
import { r as ContactBand, s as TeamGrid, t as Approach } from "./sections-B_ZJtSam.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DEOPmQdl.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "من نحن · ٠٢",
			title: "شركاء يدخلون الغرفة، لا شرائح تُرسل بالبريد.",
			lead: "منذ ٢٠٠٨ نعمل مع شركات عائلية وصناديق ومؤسسات نمت أسرع من هياكلها. دورنا أن نعيد ترتيب الأولويات."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Approach, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-border bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-mark text-muted-foreground",
						children: "الفريق"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 max-w-lg text-title tracking-tight text-foreground",
						children: "أربعة شركاء. تخصص واحد: القرار."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamGrid, {})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactBand, {})
	] });
}
//#endregion
export { AboutPage as component };
