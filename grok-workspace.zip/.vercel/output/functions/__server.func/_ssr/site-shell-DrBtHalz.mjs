import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as useRouterState, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Menu, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, s as DialogTrigger, t as Dialog, u as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-shell-DrBtHalz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 active:not-disabled:scale-press [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			inverse: "bg-background text-foreground hover:bg-muted",
			outline: "border border-border bg-transparent text-foreground hover:bg-muted",
			ghost: "text-foreground hover:bg-muted",
			inverseOutline: "border border-inverse-foreground/25 bg-transparent text-inverse-foreground hover:bg-inverse-foreground/10"
		},
		size: {
			default: "h-11 px-5",
			sm: "h-9 px-3.5 text-xs",
			lg: "h-12 px-6",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var nav = [
	{
		to: "/",
		label: "الرئيسية"
	},
	{
		to: "/about",
		label: "من نحن"
	},
	{
		to: "/services",
		label: "الخدمات"
	},
	{
		to: "/work",
		label: "أعمالنا"
	},
	{
		to: "/contact",
		label: "تواصل"
	}
];
var folders = [
	{
		to: "/about",
		num: "٠١",
		label: "من نحن",
		title: "الشركة والشركاء",
		body: "منهجية العمل، والفريق الذي يدخل غرفة القرار.",
		image: "/images/about.jpg",
		imageAlt: "قاعة اجتماعات معاصرة تطل على المدينة"
	},
	{
		to: "/services",
		num: "٠٢",
		label: "الخدمات",
		title: "ستة أبواب ندخل منها",
		body: "استراتيجية، تحول، عمليات، حوكمة، توسع، وقيادات.",
		image: "/images/case-finance.jpg",
		imageAlt: "ردهة أعمال هادئة بإضاءة المساء"
	},
	{
		to: "/work",
		num: "٠٣",
		label: "أعمالنا",
		title: "أثر يُقاس",
		body: "حالات من التجزئة والطاقة والخدمات المالية.",
		image: "/images/case-retail.jpg",
		imageAlt: "داخل فرع تجزئة معاصر"
	},
	{
		to: "/contact",
		num: "٠٤",
		label: "تواصل",
		title: "اطلب استشارة",
		body: "نرد خلال يوم عمل إن كان الموضوع ضمن أبوابنا.",
		image: "/images/hero.jpg",
		imageAlt: "أفق مدينة معاصرة عند الغسق"
	}
];
var stats = [
	{
		value: "١٨",
		label: "سنة في غرف القرار"
	},
	{
		value: "١٢٠+",
		label: "مشروعاً منجزاً"
	},
	{
		value: "١٤",
		label: "سوقاً إقليمياً"
	},
	{
		value: "٩٤٪",
		label: "تجديد تعاقد"
	}
];
var services = [
	{
		num: "٠١",
		title: "الاستراتيجية والنمو",
		body: "نصوغ خيارات واضحة لمجالس الإدارة: أين نلعب، وبماذا نربح، وما الذي نتوقف عنه قبل أن يتشتت الجهد."
	},
	{
		num: "٠٢",
		title: "التحول الرقمي",
		body: "نربط التقنية بإيقاع العمل اليومي — أنظمة، بيانات، وصلاحيات — لا بمشاريع معزولة تُنسى بعد الإطلاق."
	},
	{
		num: "٠٣",
		title: "الكفاءة التشغيلية",
		body: "نقلل الهدر في سلاسل التوريد والتكلفة ودورة القرار، ونبني مؤشرات يقرأها التنفيذي قبل أن يقرأها المستشار."
	},
	{
		num: "٠٤",
		title: "الحوكمة والمخاطر",
		body: "نصمّم مجالس ولجاناً تقرر أسرع دون أن تفقد الرقابة: حدود صلاحية، تقارير قصيرة، ومساءلة شهرية."
	},
	{
		num: "٠٥",
		title: "التوسع الإقليمي",
		body: "ندخل أسواقاً جديدة بهوية محفوظة وشراكات صحيحة: ترخيص، هيكل، وتسعير يناسب كل سوق دون تآكل الأصل."
	},
	{
		num: "٠٦",
		title: "رأس المال البشري",
		body: "نرتب الهياكل القيادية ومسارات التعاقب والحوافز، حتى تبقى المعرفة داخل الشركة لا في رأس شخص واحد."
	}
];
var steps = [
	{
		num: "٠١",
		title: "نسمع بعمق",
		body: "أسابيع في غرف القرار والاجتماعات الصامتة، لا استبيانات عن بُعد. نفهم ما يُقال وما يُؤجَّل."
	},
	{
		num: "٠٢",
		title: "نختار ما يستحق",
		body: "ثلاثة رهانات لا ثلاثين مبادرة. نكتب ما نتوقف عنه بصوتٍ عالٍ، لأن النمو يبدأ من الرفض."
	},
	{
		num: "٠٣",
		title: "نبني إيقاعاً",
		body: "لجان قصيرة، مؤشرات أسبوعية، ومراجعة شهرية تُلزم الجميع. الاستراتيجية التي لا تُراجع تتحول إلى شعار."
	}
];
var cases = [
	{
		id: "retail",
		client: "سدرة للتجزئة",
		sector: "تجزئة",
		title: "إعادة بناء سلسلة التوريد لعلامة نمت أسرع من مستودعاتها",
		result: "+٢٢٪ هامش تشغيلي خلال ١٤ شهراً",
		image: "/images/case-retail.jpg",
		imageAlt: "داخل فرع تجزئة معاصر بإضاءة ناعمة وخامات حجر وخشب",
		body: "كانت سدرة تفتح فروعاً أسرع مما تستطيع سلسلة التوريد خدمته. أعدنا تصميم الشبكة، وحدّدنا ما يُصنع محلياً وما يُستورد، وربطنا الطلب الأسبوعي بالمخزون. النتيجة ليست مشروعاً منتهياً — بل إيقاع توريد يقرأه المدير كل صباح."
	},
	{
		id: "energy",
		client: "أفق للطاقة",
		sector: "طاقة",
		title: "برنامج موثوقية الأصول في محطات كانت تتوقف دون إنذار",
		result: "انخفاض التوقف غير المخطط ٤١٪",
		image: "/images/case-energy.jpg",
		imageAlt: "منشأة طاقة حديثة عند الغسق في الصحراء",
		body: "التوقف غير المخطط كان يأكل الهامش ويُربك الالتزامات. بنينا نظام صيانة تنبؤي، وأعدنا توزيع الصلاحيات بين العمليات والصيانة، وربطنا الحوافز بساعات التشغيل لا بعدد البلاغات. المحطات صارت تُدار لا تُلاحَق."
	},
	{
		id: "finance",
		client: "بنك الإيوان",
		sector: "خدمات مالية",
		title: "دخول سوقين خليجيين دون أن تتفكك هوية البنك الأم",
		result: "ترخيص وتشغيل خلال ١١ شهراً",
		image: "/images/case-finance.jpg",
		imageAlt: "ردهة خدمات مالية هادئة بإضاءة المساء",
		body: "التوسع كان قرار مجلس، لا مشروع تسويق. رتّبنا الهيكل القانوني، والحوكمة المحلية، وعرض القيمة لكل سوق. أطلق البنك عمليتين كاملتين بهوية واحدة ومعايير مخاطر لا تُساوَم."
	}
];
var team = [
	{
		name: "ليلى الحربي",
		role: "الشريكة المديرة",
		image: "/images/team-layla.jpg",
		bio: "تقود منارة منذ ٢٠١٦. سبق أن بنت مكتب استراتيجية في مجموعة صناعية، وتعمل مع مجالس شركات عائلية في لحظات التعاقب والتوسع."
	},
	{
		name: "فهد العتيبي",
		role: "شريك الاستراتيجية",
		image: "/images/team-fahd.jpg",
		bio: "١٨ سنة بين الاستشارات والصناديق. يتخصص في خيارات النمو وقرارات التوقف — وأصعب ما يكتبه هو قائمة ما لن نفعله."
	},
	{
		name: "نورا القاسم",
		role: "شريكة التحول",
		image: "/images/team-nora.jpg",
		bio: "تحول رقمي يُقاس بالقرار لا بعدد الأنظمة. عملت مع بنوك ومشغّلين على ربط البيانات بصلاحيات واضحة."
	},
	{
		name: "كريم منصور",
		role: "شريك العمليات",
		image: "/images/team-karim.jpg",
		bio: "سلاسل توريد، تكلفة، وإيقاع تشغيلي. يؤمن أن المؤشر الذي لا يُفتح كل أسبوع ليس مؤشراً."
	}
];
var insights = [
	{
		date: "مارس ٢٠٢٦",
		title: "ما بعد الرؤية: تحويل الاستراتيجية إلى إيقاع تشغيلي",
		body: "الرؤية تُكتب مرة. الإيقاع يُراجع كل شهر. الفرق بين شركة تتحدث عن النمو وشركة تحققه هو اجتماع قصير، ومؤشر واحد، وقرار بالتوقف عن مبادرة لا تخدم الرهان."
	},
	{
		date: "يناير ٢٠٢٦",
		title: "مجالس تقرر أسرع دون أن تفقد الحوكمة",
		body: "بطء المجلس ليس حكمة بالضرورة. نختصر الملف إلى ثلاث صفحات، ونفصل ما يُقرَّر عما يُحاط به علماً، ونحدد من يملك الصوت الأخير قبل دخول القاعة."
	},
	{
		date: "نوفمبر ٢٠٢٥",
		title: "التوسع الإقليمي دون تآكل الهوية",
		body: "كل سوق جديد يغري بتعديل العرض حتى يذوب الأصل. نثبت ما لا يُمس — الجودة، والمخاطر، والاسم — ونترك للتسعير والشراكة مساحة محلية واضحة."
	}
];
var clients = [
	"مجموعة النخيل",
	"أفق للطاقة",
	"دار المشرق",
	"بنك الإيوان",
	"سدرة للتجزئة",
	"مها للصناعة"
];
var serviceOptions = [
	"الاستراتيجية والنمو",
	"التحول الرقمي",
	"الكفاءة التشغيلية",
	"الحوكمة والمخاطر",
	"التوسع الإقليمي",
	"رأس المال البشري",
	"موضوع آخر"
];
function Logo({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: cn("inline-flex items-center gap-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "inline-flex size-8 items-end justify-center rounded-sm bg-foreground pb-1.5",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-4 w-1.5 rounded-sm bg-background" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-lg font-medium tracking-tight text-foreground",
				children: "منارة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium tracking-mark text-muted-foreground",
				children: "للاستشارات"
			})]
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-[1.2fr_1fr_1fr]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm leading-relaxed text-muted-foreground",
						children: "استشارات استراتيجية وتشغيلية للشركات التي كبر طموحها أسرع من أنظمتها. الرياض · دبي · القاهرة"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs font-medium tracking-mark text-muted-foreground",
					children: "الأقسام"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "text-sm text-foreground transition-opacity hover:opacity-70",
						children: item.label
					}) }, item.to))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs font-medium tracking-mark text-muted-foreground",
					children: "المكتب"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("address", {
					className: "space-y-2 text-sm not-italic leading-relaxed text-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "مركز الملك عبدالله المالي" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "البرج ٣، الطابق ٢٧ — الرياض" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "mailto:hello@manara.sa",
							className: "hover:opacity-70",
							children: "hello@manara.sa"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							dir: "ltr",
							className: "inline-block",
							children: "+966 11 414 0080"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" منارة للاستشارات. جميع الحقوق محفوظة."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "شركة مهنية مقيدة في المملكة العربية السعودية" })]
			})
		})]
	});
}
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetClose = DialogClose;
var SheetPortal = DialogPortal;
function SheetOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
		className: cn("fixed inset-0 z-50 bg-inverse/50", className),
		...props
	});
}
function SheetContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
		className: cn("fixed inset-y-0 start-0 z-50 flex h-full w-full max-w-sm flex-col bg-background p-6 text-foreground shadow-border", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute end-4 top-4 inline-flex size-11 items-center justify-center rounded-md text-foreground transition-colors duration-150 hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "إغلاق"
			})]
		})]
	})] });
}
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-8 flex flex-col gap-1.5", className),
		...props
	});
}
function SheetTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
		className: cn("font-display text-2xl text-foreground", className),
		...props
	});
}
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-background/95",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5 sm:h-18 sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-1 lg:flex",
					"aria-label": "التنقل الرئيسي",
					children: nav.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname === item.to || pathname.startsWith(`${item.to}/`);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: cn("rounded-md px-3 py-2 text-sm font-medium transition-colors duration-150", active ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"),
							children: item.label
						}, item.to);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							children: "اطلب استشارة"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
					open,
					onOpenChange: setOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							className: "lg:hidden",
							"aria-label": "فتح القائمة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "القائمة" }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex flex-col gap-1",
							"aria-label": "تنقل الجوال",
							children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetClose, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: item.to,
									className: "flex min-h-11 items-center rounded-md px-2 text-lg text-foreground transition-colors hover:bg-muted",
									children: item.label
								})
							}, item.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetClose, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "mt-8 w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									children: "اطلب استشارة"
								})
							})
						})
					] })]
				})
			]
		})
	});
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-svh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:bg-background focus:px-4 focus:py-2",
				children: "تخطي إلى المحتوى"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "content",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { cn as a, serviceOptions as c, steps as d, team as f, clients as i, services as l, SiteShell as n, folders as o, cases as r, insights as s, Button as t, stats as u };
