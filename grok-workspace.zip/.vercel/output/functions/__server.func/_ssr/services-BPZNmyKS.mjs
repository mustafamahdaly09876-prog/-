import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as PageHero } from "./page-hero-Cka1p3b-.mjs";
import { n as SiteShell } from "./site-shell-DrBtHalz.mjs";
import { a as ServicesGrid, r as ContactBand } from "./sections-B_ZJtSam.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-BPZNmyKS.js
var import_jsx_runtime = require_jsx_runtime();
function ServicesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "الخدمات · ٠٣",
			title: "ستة أبواب ندخل منها. والباقي نرفضه.",
			lead: "لا نغطي كل شيء. نختار ما نُجيده، ونكتب بوضوح ما هو خارج النطاق قبل أن يبدأ العمل."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServicesGrid, {})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactBand, {})
	] });
}
//#endregion
export { ServicesPage as component };
