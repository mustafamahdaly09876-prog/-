//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D5xxLHCL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/services",
			"/work"
		],
		preloads: ["/assets/index-KjayNTrZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-KjayNTrZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DgZ0ZxeR.js",
			"/assets/site-shell-BVq6kjnm.js",
			"/assets/sections-CK7Yuk9E.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-Di-g_R8L.js",
			"/assets/site-shell-BVq6kjnm.js",
			"/assets/sections-CK7Yuk9E.js",
			"/assets/page-hero-BgwSDPtG.js"
		]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-DDMWRm2n.js",
			"/assets/site-shell-BVq6kjnm.js",
			"/assets/page-hero-BgwSDPtG.js"
		]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-CNmuNy-x.js",
			"/assets/site-shell-BVq6kjnm.js",
			"/assets/sections-CK7Yuk9E.js",
			"/assets/page-hero-BgwSDPtG.js"
		]
	},
	"/work": {
		filePath: "/workspace/src/routes/work.tsx",
		children: void 0,
		preloads: [
			"/assets/work-B3YIQxhB.js",
			"/assets/site-shell-BVq6kjnm.js",
			"/assets/sections-CK7Yuk9E.js",
			"/assets/page-hero-BgwSDPtG.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
