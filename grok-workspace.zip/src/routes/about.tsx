import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { Approach, ContactBand, TeamGrid } from "@/components/sections";
import { SiteShell } from "@/components/site-shell";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [{ title: "من نحن — منارة" }],
  }),
});

function AboutPage() {
  return (
    <SiteShell>
      <PageHero
        eyebrow="من نحن · ٠٢"
        title="شركاء يدخلون الغرفة، لا شرائح تُرسل بالبريد."
        lead="منذ ٢٠٠٨ نعمل مع شركات عائلية وصناديق ومؤسسات نمت أسرع من هياكلها. دورنا أن نعيد ترتيب الأولويات."
      />
      <Approach />
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
          <p className="text-xs font-medium tracking-mark text-muted-foreground">الفريق</p>
          <h2 className="mt-3 max-w-lg text-title tracking-tight text-foreground">
            أربعة شركاء. تخصص واحد: القرار.
          </h2>
          <div className="mt-12">
            <TeamGrid />
          </div>
        </div>
      </section>
      <ContactBand />
    </SiteShell>
  );
}
