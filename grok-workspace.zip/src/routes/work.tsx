import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { ClientRow, ContactBand, InsightsList, WorkShowcase } from "@/components/sections";
import { SiteShell } from "@/components/site-shell";

export const Route = createFileRoute("/work")({
  component: WorkPage,
  head: () => ({
    meta: [{ title: "أعمالنا — منارة" }],
  }),
});

function WorkPage() {
  return (
    <SiteShell>
      <PageHero
        eyebrow="أعمالنا · ٠٤"
        title="أثر يُقاس، لا عرض يُروى."
        lead="ثلاث حالات من التجزئة والطاقة والخدمات المالية. المنهج واحد: رهان واضح، وإيقاع يُراجع."
      />
      <section className="border-b border-border">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
          <WorkShowcase />
          <div className="mt-16">
            <ClientRow />
          </div>
        </div>
      </section>
      <section className="border-b border-border">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
          <p className="text-xs font-medium tracking-mark text-muted-foreground">رؤى</p>
          <h2 className="mt-3 text-title tracking-tight text-foreground">ملاحظات من غرف القرار</h2>
          <div className="mt-10">
            <InsightsList />
          </div>
        </div>
      </section>
      <ContactBand />
    </SiteShell>
  );
}
