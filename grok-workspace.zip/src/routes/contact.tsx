import { createFileRoute } from "@tanstack/react-router";
import { ContactForm } from "@/components/contact-form";
import { PageHero } from "@/components/page-hero";
import { SiteShell } from "@/components/site-shell";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [{ title: "تواصل — منارة" }],
  }),
});

function ContactPage() {
  return (
    <SiteShell>
      <PageHero
        eyebrow="تواصل · ٠٥"
        title="اكتب القرار المعلّق. نعود خلال يوم عمل."
        lead="الشركة، والموضوع، والوقت المتاح. نرد إن كان الطلب ضمن أبوابنا الستة."
      />
      <section>
        <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 lg:grid-cols-2 lg:gap-20 lg:py-24">
          <div className="rounded-lg bg-card p-6 shadow-border sm:p-8">
            <ContactForm />
          </div>
          <dl className="space-y-8 text-sm">
            <div>
              <dt className="text-xs font-medium tracking-mark text-muted-foreground">المكتب</dt>
              <dd className="mt-2 text-base text-foreground">
                مركز الملك عبدالله المالي
                <br />
                البرج ٣، الطابق ٢٧ — الرياض
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium tracking-mark text-muted-foreground">البريد</dt>
              <dd className="mt-2 text-base">
                <a href="mailto:hello@manara.sa" className="text-foreground hover:opacity-70">
                  hello@manara.sa
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium tracking-mark text-muted-foreground">الهاتف</dt>
              <dd className="mt-2 text-base text-foreground">
                <span dir="ltr" className="inline-block">
                  +966 11 414 0080
                </span>
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium tracking-mark text-muted-foreground">المكاتب</dt>
              <dd className="mt-2 text-base text-foreground">الرياض · دبي · القاهرة</dd>
            </div>
          </dl>
        </div>
      </section>
    </SiteShell>
  );
}
