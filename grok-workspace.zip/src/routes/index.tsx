import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { ContactBand, Stats } from "@/components/sections";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { folders } from "@/lib/content";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [{ title: "منارة — استشارات أعمال" }],
  }),
});

function Home() {
  return (
    <SiteShell>
      <section className="border-b border-border">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-14 sm:px-8 lg:grid-cols-2 lg:gap-16 lg:py-20">
          <div>
            <p className="hero-in text-xs font-medium tracking-mark text-muted-foreground">
              منارة · الرياض منذ ٢٠٠٨
            </p>
            <h1
              className="hero-in mt-4 text-display tracking-tight text-foreground"
              style={{ animationDelay: "80ms" }}
            >
              وضوح للقرار.
              <br />
              مسافة للنمو.
            </h1>
            <p
              className="hero-in mt-5 max-w-md text-base leading-relaxed text-muted-foreground sm:text-lg"
              style={{ animationDelay: "160ms" }}
            >
              نرافق مجالس الإدارة في الاستراتيجية والتحول والتوسع — حين يكبر
              الطموح أسرع من النظام.
            </p>
            <div
              className="hero-in mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"
              style={{ animationDelay: "240ms" }}
            >
              <Button asChild size="lg">
                <Link to="/contact">
                  اطلب استشارة
                  <ArrowLeft className="size-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/about">من نحن</Link>
              </Button>
            </div>
          </div>
          <div className="hero-in overflow-hidden rounded-lg" style={{ animationDelay: "160ms" }}>
            <img
              src="/images/hero.jpg"
              alt="أبراج مالية معاصرة عند الغسق في الرياض"
              className="aspect-photo w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10 lg:aspect-square"
            />
          </div>
        </div>
      </section>

      <Stats />

      <section className="border-b border-border">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-xs font-medium tracking-mark text-muted-foreground">خريطة الموقع</p>
              <h2 className="mt-3 text-title tracking-tight text-foreground">خمسة أقسام. مسار واحد.</h2>
            </div>
            <p className="max-w-sm text-sm text-muted-foreground">
              الرئيسية، من نحن، الخدمات، أعمالنا، وتواصل — بهوية عصرية واحدة.
            </p>
          </div>
          <ul className="mt-10 grid gap-4 sm:grid-cols-2">
            {folders.map((folder) => (
              <li key={folder.to}>
                <Link
                  to={folder.to}
                  className="group flex h-full flex-col overflow-hidden rounded-lg bg-card shadow-border transition-transform duration-200 hover:-translate-y-0.5"
                >
                  <img
                    src={folder.image}
                    alt={folder.imageAlt}
                    className="aspect-video w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10"
                  />
                  <div className="flex flex-1 flex-col p-5 sm:p-6">
                    <p className="text-xs font-medium text-muted-foreground">
                      {folder.num} · {folder.label}
                    </p>
                    <h3 className="mt-2 text-lg font-medium text-foreground">{folder.title}</h3>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                      {folder.body}
                    </p>
                    <span className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-foreground">
                      ادخل القسم
                      <ArrowLeft className="size-4 transition-transform duration-150 group-hover:-translate-x-0.5" />
                    </span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <ContactBand />
    </SiteShell>
  );
}
