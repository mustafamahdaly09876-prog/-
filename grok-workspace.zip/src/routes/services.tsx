import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/page-hero";
import { ContactBand, ServicesGrid } from "@/components/sections";
import { SiteShell } from "@/components/site-shell";

export const Route = createFileRoute("/services")({
  component: ServicesPage,
  head: () => ({
    meta: [{ title: "الخدمات — منارة" }],
  }),
});

function ServicesPage() {
  return (
    <SiteShell>
      <PageHero
        eyebrow="الخدمات · ٠٣"
        title="ستة أبواب ندخل منها. والباقي نرفضه."
        lead="لا نغطي كل شيء. نختار ما نُجيده، ونكتب بوضوح ما هو خارج النطاق قبل أن يبدأ العمل."
      />
      <section className="border-b border-border">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-24">
          <ServicesGrid />
        </div>
      </section>
      <ContactBand />
    </SiteShell>
  );
}
