import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/logo";
import { nav } from "@/lib/content";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-[1.2fr_1fr_1fr]">
        <div className="space-y-4">
          <Logo />
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
            استشارات استراتيجية وتشغيلية للشركات التي كبر طموحها أسرع من أنظمتها.
            الرياض · دبي · القاهرة
          </p>
        </div>
        <div>
          <p className="mb-3 text-xs font-medium tracking-mark text-muted-foreground">الأقسام</p>
          <ul className="space-y-2">
            {nav.map((item) => (
              <li key={item.to}>
                <Link to={item.to} className="text-sm text-foreground transition-opacity hover:opacity-70">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="mb-3 text-xs font-medium tracking-mark text-muted-foreground">المكتب</p>
          <address className="space-y-2 text-sm not-italic leading-relaxed text-foreground">
            <p>مركز الملك عبدالله المالي</p>
            <p>البرج ٣، الطابق ٢٧ — الرياض</p>
            <p>
              <a href="mailto:hello@manara.sa" className="hover:opacity-70">
                hello@manara.sa
              </a>
            </p>
            <p>
              <span dir="ltr" className="inline-block">
                +966 11 414 0080
              </span>
            </p>
          </address>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <p>© {new Date().getFullYear()} منارة للاستشارات. جميع الحقوق محفوظة.</p>
          <p>شركة مهنية مقيدة في المملكة العربية السعودية</p>
        </div>
      </div>
    </footer>
  );
}
