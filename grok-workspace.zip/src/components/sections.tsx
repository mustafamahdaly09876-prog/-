import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { cases, clients, insights, services, stats, steps, team } from "@/lib/content";
import { cn } from "@/lib/utils";

export function Stats() {
  return (
    <section className="border-b border-border">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-px bg-border sm:grid-cols-4">
        {stats.map((item) => (
          <div key={item.label} className="bg-background px-5 py-8 sm:px-8 sm:py-10">
            <p className="text-3xl font-medium tracking-tight text-foreground sm:text-4xl">
              {item.value}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">{item.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function Approach() {
  return (
    <section className="border-b border-border">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 lg:grid-cols-2 lg:gap-16 lg:py-24">
        <div>
          <p className="text-xs font-medium tracking-mark text-muted-foreground">المنهجية</p>
          <h2 className="mt-3 text-title tracking-tight text-foreground">
            ثلاثة مواقف.
            <br />
            بلا ضجيج استشاري.
          </h2>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-muted-foreground sm:text-base">
            لا نبيع إطاراً جاهزاً. ندخل غرفة القرار، نرتب ما يستحق الانتباه، ونترك
            إيقاعاً تستطيع الشركة إدارته بعد أن نغادر.
          </p>
          <div className="mt-8 overflow-hidden rounded-lg">
            <img
              src="/images/about.jpg"
              alt="قاعة اجتماعات هادئة تطل على المدينة"
              className="aspect-photo w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10"
            />
          </div>
        </div>
        <ol className="flex flex-col divide-y divide-border border-t border-border">
          {steps.map((step) => (
            <li key={step.num} className="grid grid-cols-[auto_1fr] gap-4 py-8 sm:gap-8">
              <span className="text-2xl font-medium text-muted-foreground">{step.num}</span>
              <div>
                <h3 className="text-lg font-medium text-foreground">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground sm:text-base">
                  {step.body}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function ServicesGrid() {
  return (
    <ul className="grid gap-px bg-border sm:grid-cols-2">
      {services.map((service) => (
        <li key={service.num} className="bg-card p-6 sm:p-8">
          <p className="text-sm font-medium text-muted-foreground">{service.num}</p>
          <h3 className="mt-4 text-lg font-medium text-foreground">{service.title}</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{service.body}</p>
        </li>
      ))}
    </ul>
  );
}

export function WorkShowcase() {
  const [active, setActive] = useState<(typeof cases)[number]["id"]>(cases[0].id);
  const current = cases.find((item) => item.id === active) ?? cases[0];

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:gap-12">
      <div className="flex flex-col">
        {cases.map((item) => {
          const selected = item.id === current.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActive(item.id)}
              className={cn(
                "border-t border-border py-5 text-start transition-opacity duration-200",
                selected ? "opacity-100" : "opacity-45 hover:opacity-100",
              )}
            >
              <p className="text-xs text-muted-foreground">
                {item.client} · {item.sector}
              </p>
              <p className="mt-1 text-base font-medium text-foreground sm:text-lg">{item.title}</p>
            </button>
          );
        })}
        <div className="border-t border-border" />
      </div>
      <article className="overflow-hidden rounded-lg bg-card shadow-border">
        <img
          src={current.image}
          alt={current.imageAlt}
          className="aspect-video w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10"
        />
        <div className="space-y-3 p-6 sm:p-8">
          <p className="text-sm font-medium text-foreground">{current.result}</p>
          <p className="text-sm leading-relaxed text-muted-foreground sm:text-base">{current.body}</p>
        </div>
      </article>
    </div>
  );
}

export function ClientRow() {
  return (
    <div className="border-t border-border pt-8">
      <p className="text-xs font-medium tracking-mark text-muted-foreground">عملنا مع</p>
      <ul className="mt-4 flex flex-wrap gap-x-8 gap-y-3">
        {clients.map((name) => (
          <li key={name} className="text-sm text-foreground">
            {name}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function TeamGrid() {
  return (
    <ul className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
      {team.map((person) => (
        <li key={person.name} className="space-y-4">
          <div className="overflow-hidden rounded-md">
            <img
              src={person.image}
              alt={person.name}
              className="aspect-portrait w-full object-cover outline outline-1 -outline-offset-1 outline-foreground/10"
            />
          </div>
          <div>
            <h3 className="text-base font-medium text-foreground">{person.name}</h3>
            <p className="text-sm text-muted-foreground">{person.role}</p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{person.bio}</p>
          </div>
        </li>
      ))}
    </ul>
  );
}

export function InsightsList() {
  const [open, setOpen] = useState<string | null>(insights[0].title);

  return (
    <ul className="divide-y divide-border border-y border-border">
      {insights.map((item) => {
        const isOpen = open === item.title;
        return (
          <li key={item.title}>
            <button
              type="button"
              aria-expanded={isOpen}
              onClick={() => setOpen(isOpen ? null : item.title)}
              className="flex w-full items-start justify-between gap-6 py-6 text-start"
            >
              <span>
                <span className="block text-xs text-muted-foreground">{item.date}</span>
                <span className="mt-1 block text-lg font-medium text-foreground sm:text-xl">
                  {item.title}
                </span>
              </span>
              <span
                className={cn(
                  "mt-1 text-xl leading-none text-muted-foreground transition-transform duration-200",
                  isOpen && "rotate-45",
                )}
                aria-hidden="true"
              >
                +
              </span>
            </button>
            {isOpen ? (
              <p className="pb-6 text-sm leading-relaxed text-muted-foreground sm:max-w-2xl sm:text-base">
                {item.body}
              </p>
            ) : null}
          </li>
        );
      })}
    </ul>
  );
}

export function ContactBand() {
  return (
    <section className="bg-inverse text-inverse-foreground">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-16 sm:flex-row sm:items-center sm:justify-between sm:px-8 sm:py-20">
        <div>
          <p className="text-xs font-medium tracking-mark text-inverse-foreground/55">الخطوة التالية</p>
          <h2 className="mt-3 max-w-lg text-title tracking-tight text-inverse-foreground">
            إن كان القرار ثقيلاً، نبدأ من هنا.
          </h2>
        </div>
        <Button asChild variant="inverse" size="lg">
          <Link to="/contact">
            اطلب استشارة
            <ArrowLeft className="size-4" />
          </Link>
        </Button>
      </div>
    </section>
  );
}
