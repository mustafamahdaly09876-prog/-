import { useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { serviceOptions } from "@/lib/content";
import { cn } from "@/lib/utils";

const schema = z.object({
  name: z.string().trim().min(2, "اكتب الاسم كاملاً"),
  email: z.string().trim().email("البريد غير صحيح"),
  company: z.string().trim(),
  service: z.string().min(1, "اختر موضوع الاستشارة"),
  message: z.string().trim().min(12, "أضف سطراً يوضح احتياجك"),
});

type FieldErrors = Partial<Record<keyof z.infer<typeof schema>, string>>;

const STORAGE_KEY = "manara-inquiries";

export function ContactForm() {
  const [errors, setErrors] = useState<FieldErrors>({});
  const [sent, setSent] = useState(false);
  const [pending, setPending] = useState(false);

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = {
      name: String(new FormData(form).get("name") ?? ""),
      email: String(new FormData(form).get("email") ?? ""),
      company: String(new FormData(form).get("company") ?? ""),
      service: String(new FormData(form).get("service") ?? ""),
      message: String(new FormData(form).get("message") ?? ""),
    };

    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      const next: FieldErrors = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0];
        if (typeof key === "string" && !next[key as keyof FieldErrors]) {
          next[key as keyof FieldErrors] = issue.message;
        }
      }
      setErrors(next);
      return;
    }

    setErrors({});
    setPending(true);

    try {
      const existing = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]") as unknown[];
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify([{ ...parsed.data, at: new Date().toISOString() }, ...existing]),
      );
    } catch {
      /* storage may be blocked; confirmation still stands */
    }

    window.setTimeout(() => {
      setPending(false);
      setSent(true);
      toast.success("وصل طلبك. نعود إليك خلال يوم عمل.");
    }, 400);
  }

  if (sent) {
    return (
      <div className="rounded-xl bg-card p-8 shadow-border">
        <p className="font-display text-2xl text-foreground">شكراً لثقتك.</p>
        <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
          وصل طلب الاستشارة. يراجع أحد الشركاء الرسالة ويعود إليك خلال يوم عمل
          واحد على البريد الذي أرسلته.
        </p>
        <Button type="button" variant="outline" className="mt-6" onClick={() => setSent(false)}>
          إرسال رسالة أخرى
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5" noValidate>
      <Field label="الاسم" htmlFor="name" error={errors.name}>
        <Input id="name" name="name" autoComplete="name" placeholder="الاسم الكامل" />
      </Field>
      <Field label="البريد" htmlFor="email" error={errors.email}>
        <Input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          placeholder="you@company.com"
          dir="ltr"
          className="text-start"
        />
      </Field>
      <Field label="الشركة" htmlFor="company" error={errors.company}>
        <Input id="company" name="company" autoComplete="organization" placeholder="اختياري" />
      </Field>
      <Field label="موضوع الاستشارة" htmlFor="service" error={errors.service}>
        <select
          id="service"
          name="service"
          defaultValue=""
          className={cn(
            "flex h-11 w-full rounded-md border border-border bg-card px-3 text-sm text-foreground shadow-border",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          )}
        >
          <option value="" disabled>
            اختر الخدمة
          </option>
          {serviceOptions.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </Field>
      <Field label="الرسالة" htmlFor="message" error={errors.message}>
        <Textarea
          id="message"
          name="message"
          placeholder="صف القرار أو التحدي الذي تعملون عليه."
        />
      </Field>
      <Button type="submit" className="w-full sm:w-auto" disabled={pending}>
        {pending ? "جارٍ الإرسال…" : "إرسال الطلب"}
      </Button>
    </form>
  );
}

function Field({
  label,
  htmlFor,
  error,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {error ? <p className="text-xs text-danger">{error}</p> : null}
    </div>
  );
}
