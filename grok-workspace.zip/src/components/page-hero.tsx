export function PageHero({
  eyebrow,
  title,
  lead,
}: {
  eyebrow: string;
  title: string;
  lead?: string;
}) {
  return (
    <section className="border-b border-border">
      <div className="mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-20">
        <p className="text-xs font-medium tracking-mark text-muted-foreground">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl text-display tracking-tight text-foreground">{title}</h1>
        {lead ? (
          <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            {lead}
          </p>
        ) : null}
      </div>
    </section>
  );
}
