import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <Link
      to="/"
      className={cn(
        "inline-flex items-center gap-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        className,
      )}
    >
      <span
        className="inline-flex size-8 items-end justify-center rounded-sm bg-foreground pb-1.5"
        aria-hidden="true"
      >
        <span className="block h-4 w-1.5 rounded-sm bg-background" />
      </span>
      <span className="flex flex-col leading-none">
        <span className="text-lg font-medium tracking-tight text-foreground">منارة</span>
        <span className="text-xs font-medium tracking-mark text-muted-foreground">
          للاستشارات
        </span>
      </span>
    </Link>
  );
}
